package com.example.project1763.Model

data class SliderModel(val url:String="")
